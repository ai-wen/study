this project is based on openssl
I will change this to suit the vpn
this project according to GM/T 0024-2014 
# myssl
