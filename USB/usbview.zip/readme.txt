This is a somehow enhanced version of the Microsoft USBVIEW sample:

* Interprets "usb.ids" file for decoding USB vendor and product IDs
* Decodes HID descriptors using "usb.ids" file
* Copes with Windows2000 problems of different APIs to Full-Speed and High-Speed controllers
* Supports super-speed USB (a little bit)
* Remembers its window and divider position
* Automatic refresh on USB device tree change
* Different executables for Win98, WinNT (32 bit, from 2k upto 8), x64
* Bilingual GUI (German/English) - only for menu and about box
* Project files for MSVC 6 and MSVC 2008 included
* Unicode support

Henrik Haftmann, 130717
