/*++
Copyright (c) 1997-1998 Microsoft Corporation

Module Name:	USBVIEW.H
Abstract:	This is the header file for USBVIEW
Environment:	user mode
Revision Hist:	04-25-97: created

--*/

//*****************************************************************************
// I N C L U D E S
//*****************************************************************************

#include <commctrl.h>
#include <usbioctl.h>
#include <usbiodef.h>

#include "usbdesc.h"

//*****************************************************************************
// P R A G M A S
//*****************************************************************************

#pragma intrinsic(memset,memcpy)

//*****************************************************************************
// D E F I N E S
//*****************************************************************************

#ifdef  DEBUG
#undef  DBG
#define DBG 1
#endif

#if DBG
#define OOPS() Oops(__FILE__, __LINE__)
#else
#define OOPS()
#endif


#if DBG

#define ALLOC(dwBytes) MyAlloc(__FILE__, __LINE__, (dwBytes))

#define REALLOC(hMem, dwBytes) MyReAlloc((hMem), (dwBytes))

#define FREE(hMem)  MyFree((hMem))

#define CHECKFORLEAKS() MyCheckForLeaks()

#else

#define ALLOC(dwBytes) GlobalAlloc(GPTR,(dwBytes))

#define REALLOC(hMem, dwBytes) GlobalReAlloc((hMem), (dwBytes), (GMEM_MOVEABLE|GMEM_ZEROINIT))

#define FREE(hMem)  GlobalFree((hMem))

#define CHECKFORLEAKS()

#endif

#define T(x) TEXT(x)
#define elemof(x) (sizeof(x)/sizeof(*(x)))

#ifdef UNICODE
# define ASTR "%S"	// for AppendText
#else
# define ASTR "%s"
#endif

#ifndef _cplusplus
typedef BYTE bool;
enum {false,true};
#endif

typedef struct{
 short left,top,right,bottom;
}RECTS;

extern struct _CONFIG{
 RECTS WinPos;		// Window position in pixels
 char showCmd;		// Window appearance (normal, maximized, minimized)
 BYTE flags;		// CFLAG bits: AutoRefresh, ConfigDesc, EnumName, EnumGuid
 short BarLocation;	// Position of the divider, in pixels from left side
}Config;
#define CFLAG_AUTOREFRESH	0x01
#define CFLAG_CONFIGDESC	0x02
#define CFLAG_ENUM_NAME		0x04
#define CFLAG_ENUM_GUID		0x08

//
//  BOOLEAN
//  IsListEmpty(
//      PLIST_ENTRY ListHead
//      );
//

#define IsListEmpty(ListHead) \
    ((ListHead)->Flink == (ListHead))

//
//  PLIST_ENTRY
//  RemoveHeadList(
//      PLIST_ENTRY ListHead
//      );
//

#define RemoveHeadList(ListHead) \
    (ListHead)->Flink;\
    {RemoveEntryList((ListHead)->Flink)}

//
//  VOID
//  RemoveEntryList(
//      PLIST_ENTRY Entry
//      );
//

#define RemoveEntryList(Entry) {\
    PLIST_ENTRY _EX_Blink;\
    PLIST_ENTRY _EX_Flink;\
    _EX_Flink = (Entry)->Flink;\
    _EX_Blink = (Entry)->Blink;\
    _EX_Blink->Flink = _EX_Flink;\
    _EX_Flink->Blink = _EX_Blink;\
    }

//
//  VOID
//  InsertTailList(
//      PLIST_ENTRY ListHead,
//      PLIST_ENTRY Entry
//      );
//

#define InsertTailList(ListHead,Entry) {\
    PLIST_ENTRY _EX_Blink;\
    PLIST_ENTRY _EX_ListHead;\
    _EX_ListHead = (ListHead);\
    _EX_Blink = _EX_ListHead->Blink;\
    (Entry)->Flink = _EX_ListHead;\
    (Entry)->Blink = _EX_Blink;\
    _EX_Blink->Flink = (Entry);\
    _EX_ListHead->Blink = (Entry);\
    }

//*****************************************************************************
// T Y P E D E F S
//*****************************************************************************

// Callback function for walking TreeView items
//
typedef VOID
(*LPFNTREECALLBACK)(
    HWND        hTreeWnd,
    HTREEITEM   hTreeItem
);

//
// Structure used to build a linked list of String Descriptors
// retrieved from a device.
//

typedef struct _STRING_DESCRIPTOR_NODE{
    struct _STRING_DESCRIPTOR_NODE *Next;
    UCHAR                           DescriptorIndex;
    USHORT                          LanguageID;
    USB_STRING_DESCRIPTOR           StringDescriptor[0];
} STRING_DESCRIPTOR_NODE, *PSTRING_DESCRIPTOR_NODE;


// Structures assocated with TreeView items through the lParam.  When an item
// is selected, the lParam is retrieved and the structure it which it points
// is used to display information in the right-hand side edit control.
typedef struct{
 PUSB_NODE_INFORMATION			HubInfo;        // NULL if not a HUB
 LPTSTR					HubName;        // NULL if not a HUB
 PUSB_NODE_CONNECTION_INFORMATION_EX	ConnectionInfo; // NULL if root HUB
 PUSB_DESCRIPTOR_REQUEST		ConfigDesc,     // NULL if root HUB
					DeviceQualifier,OtherSpeed;
 PSTRING_DESCRIPTOR_NODE		StringDescs;
 BYTE**					HidDescs;	// NULL if no HID, first byte = interface
} USBDEVICEINFO, *PUSBDEVICEINFO;

//*****************************************************************************
// G L O B A L S
//*****************************************************************************

// USBVIEW.C
extern int TotalHubs;

// ENUM.C
extern const PCHAR ConnectionStatuses[];

//*****************************************************************************
// F U N C T I O N    P R O T O T Y P E S
//*****************************************************************************

// USBVIEW.C
HTREEITEM AddLeaf(HTREEITEM hTreeParent, LPARAM lParam, int iImage, LPCSTR lpszText,...);
void Oops(LPCTSTR File,ULONG Line);

// DISPLAY.C
bool CreateTextBuffer ();
void DestroyTextBuffer();
void UpdateEditControl (HWND hEditWnd, HWND hTreeWnd, HTREEITEM hTreeItem);
void __cdecl AppendTextBuffer(LPCSTR lpFormat,...);
void AppendHexDump(const void*,int);

// ENUM.C
void EnumerateHostControllers(HTREEITEM hTreeParent, ULONG*DevicesConnected);
void CleanupItem(HWND hTreeWnd, HTREEITEM hTreeItem);

// DEBUG.C
HGLOBAL MyAlloc(PCHAR File, ULONG Line, DWORD dwBytes);
HGLOBAL MyReAlloc(HGLOBAL hMem, DWORD dwBytes);
HGLOBAL MyFree(HGLOBAL hMem);
void MyCheckForLeaks();

// DEVNODE.C
PTSTR DriverNameToDeviceDesc(PTSTR DriverName);

// DISPAUD.C
BOOL DisplayAudioDescriptor (PUSB_AUDIO_COMMON_DESCRIPTOR CommonDesc, UCHAR bInterfaceSubClass);

// disphid.c
void DisplayHidDescriptor(const USB_HID_DESCRIPTOR*HidDesc, const BYTE*data);

// vndrlist.c
extern const char USBVendorIDs[];

// usbids.c
#define DEF(x)
const char* _stdcall Lookup(int twoCC, int pri, int sec DEF(-1), int ter DEF(-1));
// some twoCC codes here (prefixes in "usb.ids" file):
// 0    = USB VID / PID
// 'C'  = USB class / subclass / protocol
// 'L'  = USB (= Windows) Language / Sublanguage
// 'TA' = Audio class terminal type
// 'TV' = Video class terminal Type
// 'IH' = HID descriptor types
// 'R'  = HID descriptor item types
// 'CH' = HID country code / keymap type
// 'UH' = HID usage table / usage
// 'IB' = HID physical descriptor's bias
// 'HP' = HID physical descriptor's item
bool UsbIdsLoad(LPCTSTR filename);
void UsbIdsFree();
